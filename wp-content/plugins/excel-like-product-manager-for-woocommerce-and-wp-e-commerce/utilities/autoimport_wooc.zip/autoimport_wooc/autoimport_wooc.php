<?php
///////////////////////////////////////////////////////
///SET YOUR SITE /wp-admin URL HERE:///////////////////
$WP_SITE_URL = "http://yoursite.com";
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
function configure_curl(&$ch,$cookie,$url){
	$timeout = 60 * 15;//15 min
	curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1" );
	curl_setopt( $ch, CURLOPT_URL, $url );
	curl_setopt( $ch, CURLOPT_COOKIEJAR, $cookie );
	curl_setopt( $ch, CURLOPT_COOKIEFILE,$cookie);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_ENCODING, "" );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );    # required for https urls
	curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_TIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
	curl_setopt( $ch, CURLOPT_HEADER, false );
};

$chosen_create_t = 0;
$chosen_file     = NULL; 

$current_path = dirname(__FILE__);
$dir = opendir($current_path); 
while(false !== ( $file = readdir($dir)) ) { 
	if (( $file != '.' ) && ( $file != '..' ) && (!is_dir($current_path . DIRECTORY_SEPARATOR . $file))) { 
		$ext = pathinfo($file, PATHINFO_EXTENSION);
		if($ext === 'csv'){
		    $ctime = filectime($current_path. DIRECTORY_SEPARATOR . $file);
			if($ctime > $chosen_create_t){
				$chosen_create_t = $ctime;
				$chosen_file     = realpath($current_path. DIRECTORY_SEPARATOR . $file);
			}
		}
	}
}

if(!$chosen_file){
?>
   <h1>NO FILES FOR UPLOAD</h1>
<?php
	return;
}

$content  = "";
$response = NULL;

$post_fields = array(
	   "do_import"      => 1,
	   "remote_import"  => 1,
	   "file_timestamp" => $chosen_create_t,
	   "file"           => "@".$chosen_file
);
 
do{
	
	
	
	$ch = curl_init();
	configure_curl($ch, "", $WP_SITE_URL."/admin-ajax.php?action=pelm_frame_display&page=productexcellikemanager-wooc&elpm_shop_com=wooc&pelm_full_screen=1" );
	
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields );		
	
			
	$content     = curl_exec( $ch);
	$response    = curl_getinfo( $ch );
	$post_fields = array();
	
	if($response['http_code'] == "200"){
		if(stripos($content,'<form') !== false){
			
			$doc = new DOMDocument();
			$doc->loadHTML($content);
			$doc->normalizeDocument();
			
			$form_el = null;
			$forms = $doc->getElementsByTagName("form");
			
			foreach ($forms as $form){
				$form_el = $form;
				break;
			}
				
			if($form_el){
				
				$inputs = $form_el->getElementsByTagName("input");
				
				foreach($inputs as $input){
					if(!$input->getAttribute("name")) 
						continue;
					$post_fields[$input->getAttribute("name")] = $input->getAttribute("value");
				}
				
				$post_fields["remote_import"] = 1;
				$chosen_create_t++;
				$post_fields["file_timestamp"] = $chosen_create_t;
				
				
			}else
				break;
		}
	}
	
	
}while($response['http_code'] == "200" && !empty($post_fields));



curl_close ( $ch );
		
if($response['http_code'] == "200"){
   echo $content;		
}else{
   ?>
   <h1>ERROR</h1>
   <table>
	   <?php
	   foreach($response as $key => $val){
	   ?>
	   <tr>
		   <td><?php echo $key; ?></td>
		   <td><?php echo $val; ?></td>
	   </tr>
	   <?php
	   }
	   ?>
   <table>
   <?php
}
?>