<?php
///////////////////////////////////////////////////////
///SET YOUR SITE /wp-admin URL HERE:///////////////////
$WP_SITE_URL = "http://yoursite.com";
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
function configure_curl(&$ch,$cookie,$url){
	$timeout = 60 * 15;//15 min
	curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1" );
	curl_setopt( $ch, CURLOPT_URL, $url );
	curl_setopt( $ch, CURLOPT_COOKIEJAR, $cookie );
	curl_setopt( $ch, CURLOPT_COOKIEFILE,$cookie);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_ENCODING, "" );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );    # required for https urls
	curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_TIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
	curl_setopt( $ch, CURLOPT_HEADER, false );
};

$chosen_create_t = 0;
$chosen_file     = NULL; 

$current_path = dirname(__FILE__);
$dir = opendir($current_path); 
while(false !== ( $file = readdir($dir)) ) { 
	if (( $file != '.' ) && ( $file != '..' ) && (!is_dir($current_path . DIRECTORY_SEPARATOR . $file))) { 
		$ext = pathinfo($file, PATHINFO_EXTENSION);
		if($ext === 'csv'){
		    $ctime = filectime($current_path. DIRECTORY_SEPARATOR . $file);
			if($ctime > $chosen_create_t){
				$chosen_create_t = $ctime;
				$chosen_file     = realpath($current_path. DIRECTORY_SEPARATOR . $file);
			}
		}
	}
}

if(!$chosen_file){
?>
   <h1>NO FILES FOR UPLOAD</h1>
<?php
	return;
}


$ch = curl_init();
configure_curl($ch, "", $WP_SITE_URL."/admin-ajax.php?action=pelm_frame_display&page=productexcellikemanager-wpsc&elpm_shop_com=wpsc&pelm_full_screen=1" );
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, array(
   "do_import"      => 1,
   "remote_import"  => 1,
   "file_timestamp" => $chosen_create_t,
   "file"           => "@".$chosen_file
));		
		
$content = curl_exec( $ch);
$response = curl_getinfo( $ch );
curl_close ( $ch );
		
if($response['http_code'] == "200"){
   echo $content;		
}else{
   ?>
   <h1>ERROR</h1>
   <table>
	   <?php
	   foreach($response as $key => $val){
	   ?>
	   <tr>
		   <td><?php echo $key; ?></td>
		   <td><?php echo $val; ?></td>
	   </tr>
	   <?php
	   }
	   ?>
   <table>
   <?php
}
?>